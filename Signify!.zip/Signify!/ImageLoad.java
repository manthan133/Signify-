import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class ImageLoad
{
    public static void main(String[] args)
    {
        BufferedImage img = null;
        try 
        {
            File ifile = new File("img1.jpg");
            img = ImageIO.read(ifile);
            
            //System.out.println(ifile.length());
            
            for(int i=0;i<img.getHeight();i++)
            {
                for(int j=0;j<img.getWidth();j++)
                {
                    Color myColor;
                    
                    if((i+j)%2 == 0)
                    {
                        myColor = new Color(0,112,112,255);
                    }
                    else
                    {
                        myColor = new Color(0,112,112,255);
                    }
                    
                    img.setRGB(i,j,myColor.getRGB());
                    //System.out.println(myColor.getRed()+" "+myColor.getGreen()+" "+myColor.getBlue()+" "+myColor.getAlpha());
                }
            }
            
            File outputfile = new File("black.png");
            ImageIO.write(img, "png", outputfile);
            
            System.out.println("Done!");
        } 
        catch (IOException e) 
        {
        }
    }
    
    public static void hideData(String text,String path)
    {
        byte[] nibbles = getNibbles(text);
        
        BufferedImage img = null;
        
        try 
        {
            img = ImageIO.read(new File(path));
            
            for(int i=0;i<img.getHeight();i++)
            {
                for(int j=0;j<img.getWidth();j++)
                {
                    Color myColor;
                    
                    if((i+j)%2 == 0)
                    {
                        myColor = new Color(0,112,112,255);
                    }
                    else
                    {
                        myColor = new Color(0,112,112,255);
                    }
                    
                    img.setRGB(i,j,myColor.getRGB());
                    //System.out.println(myColor.getRed()+" "+myColor.getGreen()+" "+myColor.getBlue()+" "+myColor.getAlpha());
                }
            }
            
            String finalPath = "answer.jpg"; //_Signify
            File outputfile = new File(finalPath);
            ImageIO.write(img, "png", outputfile);
            
            System.out.println("Done!");
        } 
        catch (IOException e) 
        {
        }
    }
    
    public static byte[] getNibbles(String text)
    {
        byte[] bytes = text.getBytes();
        byte[] nibbles = new byte[bytes.length*2];
        
        int len = bytes.length;
        int k=0;
        
        for(int i=0;i<len;i++)
        {
            nibbles[k++]=(byte)(bytes[i]>>4);
            nibbles[k++]=(byte)(bytes[i]&15);
        }
        
        System.out.println(k);
        
        return nibbles;
    }
}